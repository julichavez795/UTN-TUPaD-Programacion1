class GenerarOrdenComprasMain:
    def menuPrincipal(self):
        
        print("MENU PRINCIPAL")
        print("a- Ver Orden de compras cargadas")
        print("b- Cargar 1 o mas ordenes de compra")
        print("c-Generar archivo de ordenes de compra por numero")

